import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import {
  Search, Heart, ShoppingBag, User, ChevronRight, Star, SlidersHorizontal, ArrowLeft,
  Trash2, Home, Grid2X2, MapPin, ShieldCheck, Check, X, Plus, Minus, CreditCard,
  Smartphone, Banknote, MapPinned, LocateFixed, PackageCheck, Sparkles, Truck,
  ChevronDown, CheckCircle2, Circle, RotateCcw
} from 'lucide-react';
import './style.css';

const categories = [
  ['Mobiles','📱','smartphone'],['Laptops','💻','laptop'],['Audio','🎧','headphones'],['Gaming','🎮','gaming console'],['Wearables','⌚','smartwatch'],
  ['Cameras','📷','camera'],['Accessories','🔌','tech accessories'],['Fashion','👕','fashion'],['Home','🏠','home decor'],['TV & Streaming','📺','smart tv'],
  ['Tablets','▣','tablet'],['PC Components','🖥️','computer hardware'],['Networking','📡','wifi router'],['Appliances','⚙️','home appliance'],['Beauty','✨','beauty product'],
  ['Fitness','🏋️','fitness equipment'],['Shoes','👟','sneakers'],['Bags','👜','backpack'],['Books','📚','books'],['Office','🗂️','office desk'],
  ['Toys','🧸','toys'],['Travel','🧳','travel luggage'],['Kitchen','🍳','kitchen'],['Automotive','🚗','car accessories'],['Pet Supplies','🐾','pet supplies']
];

const productTemplates = [
  ['Mobiles','Aero X1 5G Smartphone',29999,['smartphone','mobile phone']],
  ['Mobiles','Nova Pro Max Smartphone',54999,['smartphone','phone']],
  ['Mobiles','Pixel Edge 256GB',44999,['smartphone','android phone']],
  ['Mobiles','Pulse 5G Lite',17999,['smartphone','mobile']],
  ['Laptops','ZenBook Air 14',74990,['laptop','ultrabook']],
  ['Laptops','ProBook Creator 15',89990,['laptop','computer']],
  ['Laptops','NoteFlex Student 15',48990,['laptop','student laptop']],
  ['Laptops','GameCore 16 RTX',119990,['gaming laptop','laptop']],
  ['Audio','SoundMax ANC Headphones',7999,['headphones','wireless headphones']],
  ['Audio','AirBeat Pro Earbuds',3499,['earbuds','wireless earbuds']],
  ['Audio','BoomBox Mini Speaker',2999,['bluetooth speaker','speaker']],
  ['Audio','Studio Wireless Headset',12990,['headphones','studio headphones']],
  ['Gaming','GameStation Wireless Controller',4499,['gaming controller','gamepad']],
  ['Gaming','RGB Mechanical Gaming Keyboard',5999,['gaming keyboard','keyboard']],
  ['Gaming','Pulse 27 Gaming Monitor',21999,['gaming monitor','computer monitor']],
  ['Gaming','Pro Gaming Mouse 26K',2999,['gaming mouse','computer mouse']],
  ['Wearables','FitTrack AMOLED Watch',4999,['smartwatch','fitness watch']],
  ['Wearables','ActiveBand 3 Fitness Band',1999,['fitness tracker','smart band']],
  ['Wearables','Titan Steel Smartwatch',8999,['smartwatch','watch']],
  ['Cameras','VisionMirror 4K Camera',62999,['mirrorless camera','camera']],
  ['Cameras','PocketCam Creator Kit',32999,['vlogging camera','camera']],
  ['Cameras','ZoomPro 70-300 Lens',45999,['camera lens','photography']],
  ['Accessories','65W GaN Fast Charger',1999,['phone charger','charger']],
  ['Accessories','USB-C 8-in-1 Hub',2999,['usb hub','computer accessories']],
  ['Accessories','20,000mAh Power Bank',1799,['power bank','portable charger']],
  ['Accessories','Braided USB-C Cable 2m',599,['usb cable','charging cable']],
  ['Fashion','Relaxed Fit Oversized Tee',999,['tshirt','streetwear']],
  ['Fashion','Everyday Oxford Shirt',1799,['mens shirt','fashion']],
  ['Fashion','Minimal Denim Jacket',2499,['denim jacket','fashion']],
  ['Fashion','Classic Straight Trousers',1999,['trousers','pants']],
  ['Home','Cloud Comfort Cushion',899,['home cushion','home decor']],
  ['Home','Nordic Floor Lamp',3499,['floor lamp','home decor']],
  ['Home','Smart Aroma Diffuser',2499,['aroma diffuser','home']],
  ['Home','Minimal Wall Clock',1299,['wall clock','home decor']],
  ['TV & Streaming','Vision 55 4K QLED TV',57999,['smart tv','television']],
  ['TV & Streaming','CinemaBar 2.1 Soundbar',11999,['soundbar','home theater']],
  ['TV & Streaming','StreamStick 4K',3999,['streaming device','tv']],
  ['TV & Streaming','Ultra 65 LED Smart TV',69999,['smart tv','television']],
  ['Tablets','Tab Air 11 Wi-Fi',34999,['tablet','ipad style tablet']],
  ['Tablets','StudyTab 10 LTE',18999,['tablet','android tablet']],
  ['Tablets','ProTab OLED 12.9',64999,['tablet','oled tablet']],
  ['PC Components','RTX Gaming Graphics Card',54999,['graphics card','gpu']],
  ['PC Components','Ryzen Creator Processor',28999,['computer processor','cpu']],
  ['PC Components','32GB DDR5 Memory Kit',9999,['ram','computer memory']],
  ['PC Components','1TB NVMe Gen4 SSD',6999,['nvme ssd','computer storage']],
  ['Networking','Wi-Fi 6 AX3000 Router',6999,['wifi router','router']],
  ['Networking','Mesh Wi-Fi 3 Pack',12999,['mesh wifi','wifi system']],
  ['Networking','2.5G Ethernet Switch',4999,['network switch','ethernet']],
  ['Appliances','RapidCook Air Fryer',6999,['air fryer','kitchen appliance']],
  ['Appliances','CoolBreeze Tower Fan',4999,['tower fan','home appliance']],
  ['Appliances','SteamPro Garment Steamer',2999,['garment steamer','home appliance']],
  ['Appliances','AutoClean Vacuum Cleaner',8999,['vacuum cleaner','home appliance']],
  ['Beauty','Hydra Glow Face Serum',799,['face serum','skincare']],
  ['Beauty','Daily Care Hair Dryer',2499,['hair dryer','beauty']],
  ['Beauty','SkinMist Facial Steamer',1999,['facial steamer','skincare']],
  ['Beauty','Everyday Grooming Kit',1499,['grooming kit','personal care']],
  ['Fitness','AdjustFit Dumbbell Set',4999,['dumbbells','fitness equipment']],
  ['Fitness','Foldable Yoga Mat Pro',1299,['yoga mat','fitness']],
  ['Fitness','Resistance Band Set',999,['resistance bands','fitness']],
  ['Fitness','HomeSpin Exercise Bike',15999,['exercise bike','fitness equipment']],
  ['Shoes','Urban Runner Sneakers',2999,['running shoes','sneakers']],
  ['Shoes','Classic Court Trainers',2499,['sneakers','shoes']],
  ['Shoes','TrailFlex Outdoor Shoes',3999,['hiking shoes','outdoor shoes']],
  ['Shoes','Everyday Comfort Loafers',2799,['loafers','shoes']],
  ['Bags','Everyday Tech Backpack',2199,['backpack','travel bag']],
  ['Bags','Urban Sling Bag',999,['sling bag','fashion bag']],
  ['Bags','Work Laptop Backpack',2999,['laptop backpack','backpack']],
  ['Bags','Weekend Duffel Bag',2499,['duffel bag','travel bag']],
  ['Books','The Focus Habit',499,['book','self improvement book']],
  ['Books','Modern Science Explained',699,['science book','book']],
  ['Books','The Startup Playbook',599,['business book','book']],
  ['Books','Design Thinking Basics',449,['design book','book']],
  ['Office','Modular Desk Organizer',699,['desk organizer','office supplies']],
  ['Office','ErgoMesh Office Chair',8999,['office chair','desk chair']],
  ['Office','LED Study Desk Lamp',1299,['desk lamp','office']],
  ['Office','Wireless Productivity Mouse',1599,['office mouse','computer mouse']],
  ['Toys','BuildMaster Creative Blocks',1999,['building blocks','toys']],
  ['Toys','RoboBot STEM Kit',2499,['stem toy','robot toy']],
  ['Toys','Remote Racer Car',1799,['remote control car','toy car']],
  ['Toys','Plush Buddy Bear',899,['teddy bear','plush toy']],
  ['Travel','Cabin Pro Trolley 20-inch',3999,['carry on luggage','suitcase']],
  ['Travel','Travel Organizer Set',999,['travel organizer','packing cubes']],
  ['Travel','Neck Pillow Memory Foam',799,['travel pillow','travel']],
  ['Travel','Compact Travel Backpack',2499,['travel backpack','backpack']],
  ['Kitchen','Granite Non-Stick Pan',1299,['non stick pan','cookware']],
  ['Kitchen','Chef Knife 3-Piece Set',1499,['kitchen knives','cookware']],
  ['Kitchen','BrewMate Coffee Maker',4999,['coffee maker','kitchen appliance']],
  ['Kitchen','Glass Storage Container Set',1199,['food storage','kitchen']],
  ['Automotive','Magnetic Car Phone Holder',699,['car phone holder','car accessory']],
  ['Automotive','Tyre Inflator Pro',2499,['car tyre inflator','automotive']],
  ['Automotive','DashCam Full HD',3999,['dash camera','car accessories']],
  ['Automotive','Car Cleaning Kit',999,['car cleaning','automotive']],
  ['Pet Supplies','PawCare Grooming Kit',999,['pet grooming','dog supplies']],
  ['Pet Supplies','Automatic Pet Water Fountain',1999,['pet water fountain','pet supplies']],
  ['Pet Supplies','Comfort Pet Bed',1499,['pet bed','dog bed']],
  ['Pet Supplies','Interactive Treat Toy',699,['pet toy','dog toy']]
];

const categoryMeta = Object.fromEntries(categories.map(c => [c[0], c]));
const money = n => new Intl.NumberFormat('en-IN', { style:'currency', currency:'INR', maximumFractionDigits:0 }).format(n);
const imageFor = (keywords, id) => `https://loremflickr.com/640/640/${encodeURIComponent(keywords[0])}?lock=${id}`;

const products = Array.from({length:101000}, (_, i) => {
  const t = productTemplates[i % productTemplates.length];
  const batch = Math.floor(i / productTemplates.length);
  const priceFactor = 1 + (((i * 17) % 23) - 11) / 100;
  return {
    id:i+1,
    name: batch ? `${t[1]} ${batch + 1}` : t[1],
    category:t[0],
    price:Math.max(199, Math.round((t[2] * priceFactor) / 10) * 10),
    image:imageFor(t[3], i+1),
    fallback:`https://picsum.photos/seed/zelvio-${i+1}/640/640`,
    rating:(4 + ((i * 7) % 10) / 10).toFixed(1),
    reviews:127 + ((i * 73) % 98000),
    keywords:t[3]
  };
});

function Ad({label='ADVERTISEMENT'}) { return <div className="ad"><span>{label}</span><b>Responsive ad slot</b></div>; }

function ProductImage({product, className=''}) {
  const [src,setSrc] = useState(product.image);
  return <img className={className} loading="lazy" src={src} alt={product.name} onError={()=>src !== product.fallback && setSrc(product.fallback)} />;
}

function ProductCard({product,onOpen,onAdd,wished,onWish}) {
  return <article className="product-card" onClick={()=>onOpen(product)}>
    <div className="product-image"><ProductImage product={product}/>
      <button className={`wish ${wished?'active':''}`} onClick={e=>{e.stopPropagation();onWish(product.id)}}>{wished?'♥':'♡'}</button>
      {product.id%5===0 && <span className="deal-badge">DEAL</span>}
    </div>
    <div className="product-body"><small>{product.category}</small><h3>{product.name}</h3>
      <div className="rating"><Star size={11} fill="currentColor"/> {product.rating} <em>({product.reviews.toLocaleString()})</em></div>
      <div className="price">{money(product.price)} <del>{money(Math.round(product.price*1.22))}</del></div>
      <button className="add-btn" onClick={e=>{e.stopPropagation();onAdd(product)}}>Add to cart</button>
    </div>
  </article>;
}

function Modal({children,onClose,title}) { return <div className="modal-backdrop" onMouseDown={onClose}><div className="modal" onMouseDown={e=>e.stopPropagation()}><div className="modal-head"><h2>{title}</h2><button onClick={onClose}><X/></button></div>{children}</div></div>; }

function App(){
  const [page,setPage]=useState('home');
  const [category,setCategory]=useState('All');
  const [query,setQuery]=useState('');
  const [selected,setSelected]=useState(null);
  const [cart,setCart]=useState(()=>JSON.parse(localStorage.getItem('zelvio-cart')||'[]'));
  const [wishlist,setWishlist]=useState(()=>JSON.parse(localStorage.getItem('zelvio-wishlist')||'[]'));
  const [address,setAddress]=useState(()=>JSON.parse(localStorage.getItem('zelvio-address')||'null'));
  const [toast,setToast]=useState('');
  const [sort,setSort]=useState('relevance');
  const [filtersOpen,setFiltersOpen]=useState(false);
  const [maxPrice,setMaxPrice]=useState(200000);
  const [locationOpen,setLocationOpen]=useState(false);
  const [addressOpen,setAddressOpen]=useState(false);
  const [orderData,setOrderData]=useState({name:'',phone:'',line1:'',city:'Lucknow',state:'Uttar Pradesh',pin:'226001',type:'Home'});
  const [payment,setPayment]=useState('upi');
  const [paymentDetail,setPaymentDetail]=useState('');
  const [orderStage,setOrderStage]=useState('idle');
  const [lastOrder,setLastOrder]=useState(null);

  useEffect(()=>localStorage.setItem('zelvio-cart',JSON.stringify(cart)),[cart]);
  useEffect(()=>localStorage.setItem('zelvio-wishlist',JSON.stringify(wishlist)),[wishlist]);
  useEffect(()=>{if(address) localStorage.setItem('zelvio-address',JSON.stringify(address));},[address]);

  const showToast=msg=>{setToast(msg);clearTimeout(showToast.t);showToast.t=setTimeout(()=>setToast(''),1800)};
  const go=target=>{setPage(target);setSelected(null);window.scrollTo({top:0,behavior:'smooth'});};
  const openProduct=p=>{setSelected(p);setPage('product');window.scrollTo({top:0,behavior:'smooth'});};
  const toggleWish=id=>setWishlist(w=>w.includes(id)?w.filter(x=>x!==id):[...w,id]);
  const addToCart=p=>{const item={...p,cartKey:`${p.id}-${Date.now()}-${Math.random().toString(36).slice(2,7)}`,qty:1};setCart(c=>[...c,item]);showToast(`${p.name} added to cart`)};
  const changeQty=(id,delta)=>setCart(c=>{const idx=c.findIndex(x=>x.cartKey===id);if(idx<0)return c;const next=[...c];next[idx]={...next[idx],qty:Math.max(1,(next[idx].qty||1)+delta)};return next});
  const removeCart=id=>setCart(c=>c.filter(x=>x.cartKey!==id));
  const cartTotal=cart.reduce((s,p)=>s+p.price*(p.qty||1),0);

  const filtered=useMemo(()=>{
    const q=query.trim().toLowerCase();
    let list=products;
    if(category!=='All') list=list.filter(p=>p.category===category);
    if(q) list=list.filter(p=>`${p.name} ${p.category} ${p.keywords.join(' ')}`.toLowerCase().includes(q));
    list=list.filter(p=>p.price<=maxPrice);
    if(sort==='price-low') list=[...list].sort((a,b)=>a.price-b.price);
    if(sort==='price-high') list=[...list].sort((a,b)=>b.price-a.price);
    if(sort==='rating') list=[...list].sort((a,b)=>Number(b.rating)-Number(a.rating));
    return list;
  },[category,query,maxPrice,sort]);

  const search=val=>{setQuery(val);setPage('search');};
  const setCategoryAndSearch=name=>{setCategory(name);setQuery('');setPage(name==='All'?'home':'search');window.scrollTo({top:0,behavior:'smooth'})};

  const categoryButtons=[['All','✨'],...categories];
  const flash=products.filter(p=>p.id%17===0).slice(0,8);
  const forYou=products.filter(p=>p.id%13===0).slice(0,8);

  const saveAddress=()=>{
    if(!orderData.name||!orderData.phone||!orderData.line1||!orderData.pin){showToast('Please complete your address');return;}
    setAddress(orderData);setAddressOpen(false);showToast('Address saved');
  };
  const detectLocation=()=>{
    if(!navigator.geolocation){showToast('Location is not supported here');return;}
    showToast('Requesting location permission…');
    navigator.geolocation.getCurrentPosition(()=>{showToast('Location detected — please confirm your address');setLocationOpen(false);setAddressOpen(true)},()=>showToast('Location permission was not granted'));
  };
  const placeOrder=()=>{
    if(!address){setAddressOpen(true);showToast('Add a delivery address first');return;}
    if(payment==='upi'&&!paymentDetail){showToast('Enter your UPI ID');return;}
    if(payment==='card'&&paymentDetail.length<4){showToast('Enter your card details');return;}
    setOrderStage('processing');
    setTimeout(()=>setOrderStage('success'),1500);
    setTimeout(()=>{
      const id=`ZLV${Date.now().toString().slice(-8)}`;
      setLastOrder({id,total:cartTotal,payment,address});setCart([]);setOrderStage('idle');setPage('success');window.scrollTo({top:0,behavior:'smooth'});
    },2900);
  };

  return <div className="app-shell">
    <header className="app-header">
      <div className="top-row"><button className="brand" onClick={()=>go('home')}>zelvio<span>.</span></button><div className="header-actions"><button onClick={()=>setLocationOpen(true)}><MapPin size={18}/></button><button onClick={()=>go('wishlist')}><Heart size={19}/></button><button className="cart-icon" onClick={()=>go('cart')}><ShoppingBag size={19}/>{cart.length>0&&<i>{cart.reduce((n,p)=>n+(p.qty||1),0)}</i>}</button><button onClick={()=>showToast('Account sign-in can be connected here')}><User size={19}/></button></div></div>
      <button className="delivery" onClick={()=>setLocationOpen(true)}><MapPin size={14}/><span>Deliver to <b>{address?.city||'Lucknow'}</b></span><ChevronRight size={13}/></button>
      <div className="search-box"><Search size={18}/><input value={query} onChange={e=>search(e.target.value)} placeholder="Search 101,000+ products"/><button onClick={()=>setFiltersOpen(true)}><SlidersHorizontal size={17}/></button>{query&&<button className="clear" onClick={()=>setQuery('')}><X size={15}/></button>}</div>
    </header>

    <div className="category-strip">{categoryButtons.map(([name,icon])=><button key={name} className={category===name?'selected':''} onClick={()=>setCategoryAndSearch(name)}><span>{icon}</span>{name}</button>)}</div>

    <main className="content">
      {page==='home'&&<>
        <section className="hero-card"><div className="hero-copy"><small>DISCOVER • COMPARE • SHOP</small><h1>Everything you<br/><span>actually want.</span></h1><p>Real-looking product discovery across tech, fashion, home and everyday essentials.</p><button className="hero-button" onClick={()=>go('search')}>Start shopping <ChevronRight size={17}/></button></div><div className="hero-art"><div className="hero-orb">🎧</div><div className="float-card f1">⚡ <b>Daily deals</b></div><div className="float-card f2">★ 4.8 <b>Top rated</b></div><div className="float-card f3">🛡️ Secure</div></div></section>
        <div className="trust-row"><span>✓ Secure checkout</span><span>✓ Easy returns</span><span>✓ 100K+ catalogue</span><span>✓ Smart recommendations</span></div>
        <section className="section"><div className="section-title"><h2>Explore categories</h2><button onClick={()=>go('search')}>View all <ChevronRight size={14}/></button></div><div className="category-grid">{categories.slice(0,8).map(([name,icon])=><button key={name} onClick={()=>setCategoryAndSearch(name)}><span>{icon}</span><b>{name}</b><small>{products.filter(p=>p.category===name).length.toLocaleString()}+ products</small><ChevronRight size={13}/></button>)}</div></section>
        <section className="section"><div className="section-title"><h2>⚡ Flash deals</h2><button onClick={()=>go('search')}>See all <ChevronRight size={14}/></button></div><div className="horizontal-products">{flash.map(p=><ProductCard key={p.id} product={p} onOpen={openProduct} onAdd={addToCart} wished={wishlist.includes(p.id)} onWish={toggleWish}/>)}</div></section>
        <Ad/>
        <section className="section"><div className="section-title"><h2>For you</h2><button>Personalized</button></div><div className="product-grid">{forYou.map(p=><ProductCard key={p.id} product={p} onOpen={openProduct} onAdd={addToCart} wished={wishlist.includes(p.id)} onWish={toggleWish}/>)}</div></section>
        <Ad/>
        <section className="editorial-card"><div><small>SMART SHOPPING</small><h2>Buy less.<br/>Choose better.</h2><p>Compare products, check the details and make a better-informed choice.</p><button className="secondary-button" onClick={()=>go('guides')}>Explore guides</button></div><div className="guide-mini"><div>📱<b>Phones</b><small>Compare</small></div><div>💻<b>Laptops</b><small>Best picks</small></div><div>🎧<b>Audio</b><small>Top rated</small></div></div></section>
      </>}

      {page==='search'&&<><div className="page-heading"><div><small>SHOP</small><h1>{query?`Results for “${query}”`:category}</h1><p>{filtered.length.toLocaleString()} products available</p></div><button className="filter-button" onClick={()=>setFiltersOpen(true)}><SlidersHorizontal size={15}/> Filter</button></div><div className="sort-row"><span>Showing {Math.min(filtered.length,24)} of {filtered.length.toLocaleString()}</span><select value={sort} onChange={e=>setSort(e.target.value)}><option value="relevance">Relevance</option><option value="price-low">Price: low to high</option><option value="price-high">Price: high to low</option><option value="rating">Top rated</option></select></div><div className="product-grid">{filtered.slice(0,24).map((p,i)=><React.Fragment key={p.id}><ProductCard product={p} onOpen={openProduct} onAdd={addToCart} wished={wishlist.includes(p.id)} onWish={toggleWish}/>{i===5&&<div className="grid-ad"><Ad/></div>}</React.Fragment>)}</div>{filtered.length===0&&<div className="empty-state"><Search/><h2>No products found</h2><p>Try a different product, category or price range.</p><button className="primary-button" onClick={()=>{setQuery('');setCategory('All')}}>Clear search</button></div>}</>}

      {page==='product'&&selected&&<><button className="back-button" onClick={()=>go('search')}><ArrowLeft size={16}/> Back to products</button><section className="product-detail"><div className="detail-image"><ProductImage product={selected}/><button className={`big-wish ${wishlist.includes(selected.id)?'active':''}`} onClick={()=>toggleWish(selected.id)}>{wishlist.includes(selected.id)?'♥':'♡'}</button></div><div className="detail-info"><small>{selected.category}</small><h1>{selected.name}</h1><div className="big-rating"><Star size={13} fill="currentColor"/> {selected.rating} · {selected.reviews.toLocaleString()} reviews</div><div className="big-price">{money(selected.price)} <del>{money(Math.round(selected.price*1.22))}</del></div><div className="offer">⚡ Limited deal · Free delivery on eligible orders</div><div className="spec-grid"><div><b>Availability</b><span>In stock</span></div><div><b>Delivery</b><span>2–5 business days</span></div><div><b>Returns</b><span>Easy returns</span></div><div><b>Warranty</b><span>Seller dependent</span></div></div><div className="buy-row"><button className="secondary-button" onClick={()=>toggleWish(selected.id)}><Heart size={16}/> Wishlist</button><button className="primary-button" onClick={()=>addToCart({...selected,cartKey:`${selected.id}-${Date.now()}`,qty:1})}><ShoppingBag size={16}/> Add to cart</button></div><div className="secure"><ShieldCheck size={15}/> Secure shopping experience</div></div></section><Ad label="ADVERTISEMENT · PRODUCT PAGE"/><section className="description-card"><small>PRODUCT OVERVIEW</small><h2>Why consider this product?</h2><p>{selected.name} is listed in our {selected.category} catalogue. Compare price, ratings, specifications, seller information and return terms before purchase.</p><div className="detail-tips"><div><b>Best for</b><span>Everyday shoppers comparing options.</span></div><div><b>Shopping tip</b><span>Check seller rating and warranty before ordering.</span></div></div></section></>}

      {page==='cart'&&<><div className="page-heading"><div><small>YOUR BAG</small><h1>Cart</h1><p>{cart.reduce((n,p)=>n+(p.qty||1),0)} item(s)</p></div></div>{cart.length?<><div className="cart-list">{cart.map(p=><div className="cart-item" key={p.cartKey}><ProductImage product={p}/><div className="cart-info"><b>{p.name}</b><small>{p.category}</small><strong>{money(p.price)}</strong><div className="qty"><button onClick={()=>changeQty(p.cartKey,-1)}><Minus size={13}/></button><b>{p.qty||1}</b><button onClick={()=>changeQty(p.cartKey,1)}><Plus size={13}/></button></div></div><button className="remove" onClick={()=>removeCart(p.cartKey)}><Trash2 size={17}/></button></div>)}</div><Ad/><aside className="summary-card"><h3>Order summary</h3><div><span>Subtotal</span><b>{money(cartTotal)}</b></div><div><span>Delivery</span><b>FREE</b></div><div><span>Protection</span><b>Included</b></div><hr/><div className="summary-total"><span>Total</span><b>{money(cartTotal)}</b></div><button className="primary-button full" onClick={()=>{if(!address)setAddressOpen(true);else go('checkout')}}>Proceed to checkout</button></aside></>:<div className="empty-state"><ShoppingBag/><h2>Your cart is empty</h2><p>Add something you like and it will appear here.</p><button className="primary-button" onClick={()=>go('search')}>Start shopping</button></div>}</>}

      {page==='checkout'&&<><div className="page-heading"><div><small>SECURE CHECKOUT</small><h1>Place your order</h1><p>Encrypted checkout · {cart.length} product type(s)</p></div></div><div className="checkout-layout"><div><div className="checkout-card"><div className="checkout-card-title"><h3>Delivery address</h3><button onClick={()=>setAddressOpen(true)}>Change</button></div>{address?<div className="saved-address"><div><MapPinned size={17}/></div><div><b>{address.name}</b><p>{address.line1}, {address.city}, {address.state} — {address.pin}</p><small>{address.phone} · {address.type}</small></div><CheckCircle2 size={17}/></div>:<button className="add-address" onClick={()=>setAddressOpen(true)}><Plus/> Add delivery address</button>}</div><div className="checkout-card"><h3>Payment method</h3><button className={`payment-option ${payment==='upi'?'active':''}`} onClick={()=>setPayment('upi')}><span><Smartphone/> UPI</span>{payment==='upi'?<CheckCircle2/>:<Circle/>}</button>{payment==='upi'&&<input value={paymentDetail} onChange={e=>setPaymentDetail(e.target.value)} placeholder="yourname@upi"/>}<button className={`payment-option ${payment==='card'?'active':''}`} onClick={()=>setPayment('card')}><span><CreditCard/> Card</span>{payment==='card'?<CheckCircle2/>:<Circle/>}</button>{payment==='card'&&<input value={paymentDetail} onChange={e=>setPaymentDetail(e.target.value)} placeholder="Card ending / test card number" inputMode="numeric"/>}<button className={`payment-option ${payment==='cod'?'active':''}`} onClick={()=>{setPayment('cod');setPaymentDetail('')}}><span><Banknote/> Cash on delivery</span>{payment==='cod'?<CheckCircle2/>:<Circle/>}</button></div><div className="checkout-card secure-box"><ShieldCheck/><div><b>Safe & secure</b><p>Your payment details are handled securely. Never share OTPs with anyone.</p></div></div></div><aside className="summary-card sticky-summary"><h3>Order total</h3><div><span>Items</span><b>{money(cartTotal)}</b></div><div><span>Delivery</span><b>FREE</b></div><div><span>Discount</span><b className="green">-{money(Math.round(cartTotal*.08))}</b></div><hr/><div className="summary-total"><span>Payable</span><b>{money(Math.max(0,cartTotal-Math.round(cartTotal*.08)))}</b></div><button className="primary-button full" onClick={placeOrder}><PackageCheck size={17}/> Place order</button></aside></div></>}

      {page==='success'&&<div className="success-state"><div className="success-icon"><Check/></div><small>ORDER CONFIRMED</small><h1>You're all set.</h1><p>Order <b>#{lastOrder?.id}</b> has been placed successfully.</p><div className="success-card"><div><Truck/><span>Delivery</span><b>2–5 business days</b></div><div><CreditCard/><span>Payment</span><b>{lastOrder?.payment==='cod'?'Cash on delivery':lastOrder?.payment?.toUpperCase()}</b></div><div><MapPin/><span>Deliver to</span><b>{lastOrder?.address?.city}</b></div></div><Ad label="ADVERTISEMENT · ORDER CONFIRMATION"/><button className="primary-button" onClick={()=>go('home')}>Continue shopping</button></div>}

      {page==='wishlist'&&<><div className="page-heading"><div><small>SAVED</small><h1>Wishlist</h1><p>{wishlist.length} saved item(s)</p></div></div>{wishlist.length?<div className="product-grid">{products.filter(p=>wishlist.includes(p.id)).map(p=><ProductCard key={p.id} product={p} onOpen={openProduct} onAdd={addToCart} wished onWish={toggleWish}/>)}</div>:<div className="empty-state"><Heart/><h2>No saved products</h2><p>Tap the heart on anything you love.</p></div>}</>}
      {page==='guides'&&<><div className="page-heading"><div><small>TECH HUB</small><h1>Buying guides</h1><p>Helpful comparisons before you buy.</p></div></div><div className="guide-grid">{[['📱','Best phones for students'],['💻','Best laptops under ₹60,000'],['🎧','Best earbuds under ₹5,000'],['🔋','How to choose a power bank'],['🎮','Gaming setup essentials'],['⌚','Best smartwatches for everyday use']].map(([icon,title])=><article key={title}><div>{icon}</div><small>BUYING GUIDE</small><h2>{title}</h2><p>Compare features, pricing, use cases and alternatives.</p><button className="secondary-button">Read guide <ChevronRight size={13}/></button></article>)}</div></>}
    </main>

    <nav className="bottom-nav"><button className={page==='home'?'active':''} onClick={()=>go('home')}><Home/>Home</button><button className={page==='search'?'active':''} onClick={()=>go('search')}><Grid2X2/>Shop</button><button onClick={()=>go('search')}><Search/>Search</button><button className={page==='wishlist'?'active':''} onClick={()=>go('wishlist')}><Heart/>Wishlist</button><button className={page==='cart'?'active':''} onClick={()=>go('cart')}><ShoppingBag/>Cart{cart.length>0&&<i>{cart.reduce((n,p)=>n+(p.qty||1),0)}</i>}</button></nav>
    {toast&&<div className="toast">✓ {toast}</div>}

    {filtersOpen&&<Modal title="Filter & sort" onClose={()=>setFiltersOpen(false)}><div className="filter-panel"><label>Category<select value={category} onChange={e=>setCategory(e.target.value)}><option>All</option>{categories.map(c=><option key={c[0]}>{c[0]}</option>)}</select></label><label>Maximum price <b>{money(maxPrice)}</b><input type="range" min="500" max="200000" step="500" value={maxPrice} onChange={e=>setMaxPrice(Number(e.target.value))}/></label><label>Sort<select value={sort} onChange={e=>setSort(e.target.value)}><option value="relevance">Relevance</option><option value="price-low">Price low to high</option><option value="price-high">Price high to low</option><option value="rating">Top rated</option></select></label><button className="primary-button full" onClick={()=>{setFiltersOpen(false);setPage('search')}}>Apply filters</button></div></Modal>}

    {locationOpen&&<Modal title="Delivery location" onClose={()=>setLocationOpen(false)}><div className="location-panel"><div className="location-card"><MapPinned/><div><b>{address?`Deliver to ${address.name}`:'Choose your delivery location'}</b><p>{address?`${address.city}, ${address.state} ${address.pin}`:'Set your address for accurate delivery estimates.'}</p></div></div><button className="location-action" onClick={detectLocation}><LocateFixed/><span><b>Use current location</b><small>Allow browser location access</small></span><ChevronRight/></button><button className="location-action" onClick={()=>{setLocationOpen(false);setAddressOpen(true)}}><MapPin/><span><b>Enter address manually</b><small>House, street, city and PIN</small></span><ChevronRight/></button>{address&&<button className="secondary-button full" onClick={()=>{setAddress(null);localStorage.removeItem('zelvio-address');setLocationOpen(false);showToast('Address removed')}}>Remove saved address</button>}</div></Modal>}

    {addressOpen&&<Modal title="Add delivery address" onClose={()=>setAddressOpen(false)}><div className="address-form"><div className="two"><input value={orderData.name} onChange={e=>setOrderData({...orderData,name:e.target.value})} placeholder="Full name"/><input value={orderData.phone} onChange={e=>setOrderData({...orderData,phone:e.target.value})} placeholder="Mobile number" inputMode="tel"/></div><input value={orderData.line1} onChange={e=>setOrderData({...orderData,line1:e.target.value})} placeholder="House / flat / street address"/><div className="two"><input value={orderData.city} onChange={e=>setOrderData({...orderData,city:e.target.value})} placeholder="City"/><input value={orderData.pin} onChange={e=>setOrderData({...orderData,pin:e.target.value})} placeholder="PIN code" inputMode="numeric"/></div><input value={orderData.state} onChange={e=>setOrderData({...orderData,state:e.target.value})} placeholder="State"/><div className="address-types">{['Home','Work','Other'].map(t=><button key={t} className={orderData.type===t?'active':''} onClick={()=>setOrderData({...orderData,type:t})}>{t}</button>)}</div><button className="primary-button full" onClick={saveAddress}>Save address</button></div></Modal>}

    {orderStage!=='idle'&&<div className="order-overlay"><div className="order-animation">{orderStage==='processing'?<><div className="spinner"></div><h2>Securing your order…</h2><p>Confirming payment and delivery details</p></>:<><div className="animated-check"><Check/></div><h2>Order confirmed!</h2><p>Preparing your order details…</p></>}</div><div className="confetti"><i/><i/><i/><i/><i/><i/></div></div>}
  </div>;
}

createRoot(document.getElementById('root')).render(<App/>);
