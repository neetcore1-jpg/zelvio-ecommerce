# Zelvio ecommerce app — supplied product media integration

This build integrates the product photos supplied in the conversation into the Zelvio catalog.

## Included
- Local product media for supplied phones, laptops, headphones/earbuds and smartwatches.
- Supplied-photo product cards surfaced on the home page.
- Exact featured product searches surface the supplied products first.
- Product detail galleries combine supplied photos with category-matched generic photos.
- Product galleries are swipeable on touch devices, with arrows, dots and thumbnails.
- Generated catalog products also get category-matched generic gallery photos.
- Existing cart, wishlist, checkout, orders and profile flows are preserved.

## Important
The catalog is a frontend/demo marketplace feed. Prices, stock, ratings and generic products are locally generated; they are not live marketplace inventory.
