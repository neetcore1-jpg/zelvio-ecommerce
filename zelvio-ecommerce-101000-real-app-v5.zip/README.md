# Zelvio Ecommerce v3

This version contains a 10,000-SKU local catalog across 14 departments requested by the owner:
Mobiles, Laptops, Audio, TVs, Gaming, Watches, Cameras, Electronics, Men's Fashion,
Women's Fashion, Shoes, Bags, Beauty and Printers.

## Catalog architecture
- `src/catalog.js` contains the catalog generator and image sets.
- Products are generated deterministically at startup; no 10,000-record JSON download is needed.
- The UI only renders the visible products, so the catalog can be browsed with infinite scrolling.
- Each product includes brand, price, MRP, discount, image, rating, review count, stock, keywords, description and specs.

## Important data note
This is the free/no-API version. Product images are category-matched free Unsplash images, and prices are curated INR catalog prices. They are **not live Amazon/Flipkart/Myntra prices** and the images are not copied marketplace assets. A licensed product-data API can later replace `src/catalog.js` without changing the shopping UI.
