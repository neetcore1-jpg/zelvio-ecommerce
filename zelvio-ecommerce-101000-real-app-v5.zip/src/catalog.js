// Zelvio free catalog: 10,000 locally generated SKUs across the user's 14 departments.
// Images use stable, free Unsplash image URLs and are category-matched. Prices are curated INR catalog prices,
// not live marketplace quotes; a licensed product feed can replace this module later without changing the UI.

export const categories = [
  ['Mobiles','📱','smartphone'],
  ['Laptops','💻','laptop'],
  ['Audio','🎧','headphones'],
  ['TVs','📺','television'],
  ['Gaming','🎮','gaming'],
  ['Watches','⌚','watch'],
  ['Cameras','📷','camera'],
  ['Electronics','🔌','electronics'],
  ["Men's Fashion",'👕','mens fashion'],
  ["Women's Fashion",'👗','womens fashion'],
  ['Shoes','👟','shoes'],
  ['Bags','👜','bags'],
  ['Beauty','💄','beauty'],
  ['Printers','🖨️','printer']
];

export const photoSets = {
  Mobiles:[
    'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=900&q=85',
    'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=900&q=85',
    'https://images.unsplash.com/photo-1565849904461-04a58ad377e0?w=900&q=85',
    'https://images.unsplash.com/photo-1556656793-08538906a9f8?w=900&q=85'
  ],
  Laptops:[
    'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=900&q=85',
    'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=900&q=85',
    'https://images.unsplash.com/photo-1531297484001-80022131f5a1?w=900&q=85',
    'https://images.unsplash.com/photo-1593642632823-8f785ba67e45?w=900&q=85'
  ],
  Audio:[
    'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=900&q=85',
    'https://images.unsplash.com/photo-1484704849700-f032a568e944?w=900&q=85',
    'https://images.unsplash.com/photo-1606220945770-b5b6c2c55bf1?w=900&q=85',
    'https://images.unsplash.com/photo-1572536147248-ac59a8abfa4b?w=900&q=85'
  ],
  TVs:[
    'https://images.unsplash.com/photo-1593784991095-a205069470b6?w=900&q=85',
    'https://images.unsplash.com/photo-1461151304267-38535e780c79?w=900&q=85',
    'https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=900&q=85',
    'https://images.unsplash.com/photo-1567690187548-f07b1d7bf5a9?w=900&q=85'
  ],
  Gaming:[
    'https://images.unsplash.com/photo-1593305841991-05c297ba4575?w=900&q=85',
    'https://images.unsplash.com/photo-1600080972464-8e5f35f63d08?w=900&q=85',
    'https://images.unsplash.com/photo-1605901309584-818e25960a8f?w=900&q=85',
    'https://images.unsplash.com/photo-1612287230202-1ff1d85d1bdf?w=900&q=85'
  ],
  Watches:[
    'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=900&q=85',
    'https://images.unsplash.com/photo-1551816230-ef5deaed4a26?w=900&q=85',
    'https://images.unsplash.com/photo-1579586337278-3befd40fd17a?w=900&q=85',
    'https://images.unsplash.com/photo-1546868871-7041f2a1b4e6?w=900&q=85'
  ],
  Cameras:[
    'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=900&q=85',
    'https://images.unsplash.com/photo-1606986628253-5e3e9f8f2c4b?w=900&q=85',
    'https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=900&q=85',
    'https://images.unsplash.com/photo-1510127034890-ba27508e9f1c?w=900&q=85'
  ],
  Electronics:[
    'https://images.unsplash.com/photo-1498049794561-7780e7231661?w=900&q=85',
    'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=900&q=85',
    'https://images.unsplash.com/photo-1518770660439-4636190af475?w=900&q=85',
    'https://images.unsplash.com/photo-1588508065123-287b28e013da?w=900&q=85'
  ],
  "Men's Fashion":[
    'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=900&q=85',
    'https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=900&q=85',
    'https://images.unsplash.com/photo-1617127365659-c47fa864d8bc?w=900&q=85',
    'https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?w=900&q=85'
  ],
  "Women's Fashion":[
    'https://images.unsplash.com/photo-1483985988355-763728e1935b?w=900&q=85',
    'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=900&q=85',
    'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=900&q=85',
    'https://images.unsplash.com/photo-1525507119028-ed4c629a60a3?w=900&q=85'
  ],
  Shoes:[
    'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=900&q=85',
    'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=900&q=85',
    'https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?w=900&q=85',
    'https://images.unsplash.com/photo-1495555961986-6d4c1ecb7be3?w=900&q=85'
  ],
  Bags:[
    'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=900&q=85',
    'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=900&q=85',
    'https://images.unsplash.com/photo-1594223274512-ad4803739b7c?w=900&q=85',
    'https://images.unsplash.com/photo-1566150905458-1bf1fc113f0d?w=900&q=85'
  ],
  Beauty:[
    'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=900&q=85',
    'https://images.unsplash.com/photo-1556229010-6c3f2c9ca5f8?w=900&q=85',
    'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=900&q=85',
    'https://images.unsplash.com/photo-1571781926291-c477ebfd024b?w=900&q=85'
  ],
  Printers:[
    'https://images.unsplash.com/photo-1612810436541-336d5e6e1b2b?w=900&q=85',
    'https://images.unsplash.com/photo-1516387938699-a93567ec168e?w=900&q=85',
    'https://images.unsplash.com/photo-1562564055-71e051d33c19?w=900&q=85',
    'https://images.unsplash.com/photo-1586282391129-76a6df230234?w=900&q=85'
  ]
};

const money = n => new Intl.NumberFormat('en-IN',{style:'currency',currency:'INR',maximumFractionDigits:0}).format(n);


const brandModels = {
  Mobiles:{Samsung:['Galaxy A16','Galaxy A25','Galaxy A35','Galaxy A55','Galaxy S24 FE','Galaxy S25'],OnePlus:['Nord CE4','Nord 4','Nord 5','12R','13R','13'],Xiaomi:['Redmi Note 13','Redmi Note 14','Redmi Note 14 Pro','Redmi 13','Xiaomi 14'],Motorola:['Moto G85','Moto G64','Edge 50 Fusion','Edge 50 Pro','Razr 50'],realme:['Narzo 70','Narzo 80','P1','P3','GT 6'],vivo:['V30','V40','V50','T3','T4'],OPPO:['A3','A5 Pro','F27','Reno 12','Reno 13'],Nothing:['Phone (2a)','Phone (2a) Plus','Phone (3a)','Phone (3a) Pro'],Google:['Pixel 8a','Pixel 9','Pixel 9a','Pixel 9 Pro'],Apple:['iPhone 13','iPhone 14','iPhone 15','iPhone 16','iPhone 16e']},
  Laptops:{HP:['15s','Pavilion 14','Pavilion Plus 14','Victus 15','Victus 16','Envy x360'],Lenovo:['IdeaPad Slim 3','IdeaPad Slim 5','LOQ 15','Yoga Slim 6','ThinkBook 14','Legion 5'],Dell:['Inspiron 14','Inspiron 15','Vostro 3520','G15 Gaming','XPS 13'],ASUS:['Vivobook 15','Vivobook S 14','Zenbook 14','TUF Gaming F15','ROG Strix G16'],Acer:['Aspire Lite 15','Aspire 3','Swift Go 14','Nitro V','Predator Helios Neo'],Apple:['MacBook Air 13','MacBook Air 15','MacBook Pro 14','MacBook Pro 16'],MSI:['Modern 14','Thin 15','Katana 15','Cyborg 15'],Samsung:['Galaxy Book4','Galaxy Book4 Pro','Galaxy Book5']},
  Audio:{boAt:['Airdopes 141','Airdopes 161','Nirvana Ion','Rockerz 450','Stone 350'],Sony:['WF-C510','WF-1000XM5','WH-CH520','WH-1000XM5','SRS-XB100'],JBL:['Wave Buds','Tune 520BT','Live 770NC','Flip 6','Charge 5'],OnePlus:['Nord Buds 3','Buds 3','Buds Pro 3','Bullets Wireless Z2'],Noise:['Buds VS104','Buds X Prime','Airwave Max 5','ColorFit Pro Buds'],Sennheiser:['HD 450BT','Momentum 4','Accentum'],Bose:['QuietComfort','QuietComfort Ultra','SoundLink Flex'],realme:['Buds Air 5','Buds Air 6','Buds T300']},
  TVs:{Samsung:['Crystal 4K','Crystal Vision','QLED Q60','QLED Q70','Neo QLED'],LG:['UR75','UT80','QNED80','OLED B4','OLED C4'],Sony:['Bravia 2','Bravia 3','Bravia X75L','Bravia 7'],TCL:['C655','C755','P635','P755'],Hisense:['E6N','U6K','U7K'],OnePlus:['Y1S Pro','Y1S Edge','Q1'],Acer:['Advanced I Series','V Series'],Vu:['GloLED','The Masterpiece','Cinema TV']},
  Watches:{Apple:['Watch SE','Watch Series 9','Watch Series 10','Watch Ultra 2'],Samsung:['Galaxy Watch 6','Galaxy Watch 7','Galaxy Watch FE','Galaxy Watch Ultra'],Noise:['ColorFit Pulse 4','ColorFit Pro 6','Icon 2','Voyage'],boAt:['Lunar Pro','Storm Call','Ultima Chronos','Wave Sigma'],Fossil:['Gen 6','Machine','Grant'],Titan:['Karishma','Neo','Regalia','Edge'],"Fire-Boltt":['Phoenix','Ninja Call Pro','Dream','Rise'],Garmin:['Forerunner 55','Vivoactive 5','Instinct 2','Venu 3']},
  Cameras:{Canon:['EOS R50','EOS R10','EOS R7','EOS R6 Mark II','EOS 200D II'],Nikon:['Z30','Z50','Z fc','Z5','Z6 II'],Sony:['Alpha ZV-E10','Alpha 6400','Alpha 6700','Alpha 7 III','Alpha 7 IV'],Fujifilm:['X-S20','X-T30 II','X-T50','X100VI'],GoPro:['HERO12 Black','HERO13 Black','MAX'],DJI:['Osmo Action 4','Osmo Action 5 Pro','Pocket 3'],Panasonic:['Lumix G100','Lumix S5 II','Lumix GH6']},
  Gaming:{Sony:['DualSense Wireless Controller','Pulse 3D Headset','INZONE H5','INZONE M9'],Microsoft:['Xbox Wireless Controller','Xbox Elite Series 2','Xbox Stereo Headset'],Logitech:['G102','G304','G502 X','G Pro X Superlight','G915'],Razer:['DeathAdder Essential','Viper V3 Pro','BlackShark V2','Huntsman Mini'],Redragon:['K552 Kumara','K617 Fizz','M711 Cobra'],ASUS:['TUF Gaming VG27','ROG Swift PG27','ROG Keris'],Acer:['Nitro VG240','Nitro XV272','Predator XB273'],Corsair:['K55 RGB','K70 Core','Harpoon RGB','HS80']},
  Printers:{HP:['Smart Tank 525','Smart Tank 589','Smart Tank 670','DeskJet 2820','LaserJet MFP 1188'],Canon:['PIXMA G3770','PIXMA G3010','PIXMA G570','imageCLASS MF3010'],Epson:['EcoTank L3250','EcoTank L4260','EcoTank L6270','EcoTank L8050'],Brother:['DCP-T420W','DCP-T520W','DCP-L2541DW','HL-L2321D'],Pantum:['P2500W','M6500NW','M6550NW']}
};

const configs = {
  Mobiles:{count:1000,brands:['Samsung','OnePlus','Xiaomi','Motorola','realme','vivo','OPPO','Nothing','Google','Apple'],types:['5G Smartphone','AMOLED Smartphone','Camera Smartphone','Gaming Smartphone','Budget Smartphone'],models:['Galaxy A','Galaxy M','Nord','Redmi Note','Edge','Narzo','V Series','Reno','Phone','Pixel'],base:[7999,15999,24999,34999,49999,64999,79999],tags:['8GB RAM','128GB','256GB','5G','Dual SIM']},
  Laptops:{count:700,brands:['HP','Lenovo','Dell','ASUS','Acer','Apple','MSI','Samsung'],types:['Thin Laptop','Business Laptop','Student Laptop','Creator Laptop','Gaming Laptop'],models:['Pavilion','IdeaPad','Inspiron','VivoBook','Aspire','MacBook Air','Modern','Galaxy Book'],base:[35990,45990,55990,69990,84990,109990,139990],tags:['8GB RAM','16GB RAM','512GB SSD','1TB SSD','Core i5','Ryzen 5']},
  Audio:{count:700,brands:['boAt','Sony','JBL','OnePlus','Noise','Sennheiser','Bose','realme'],types:['Wireless Earbuds','ANC Headphones','Bluetooth Speaker','Neckband','Party Speaker'],models:['Wave','Tune','Soundcore','Buds','Live','Studio','Air','Bass'],base:[799,1299,1999,2999,4999,7999,12999],tags:['Bluetooth 5.3','ANC','40H Battery','Fast Charge','IPX5']},
  TVs:{count:500,brands:['Samsung','LG','Sony','TCL','Hisense','OnePlus','Acer','Vu'],types:['4K LED Smart TV','4K QLED TV','OLED Smart TV','Google TV'],models:['Crystal','Bravia','Cinemagic','Vision','A-Series','U-Series','Frame','Pro'],base:[18999,24999,32999,44999,59999,79999,109999],tags:['43 inch','50 inch','55 inch','65 inch','75 inch','4K','Dolby Vision']},
  Gaming:{count:600,brands:['Sony','Microsoft','Logitech','Razer','Redragon','ASUS','Acer','Corsair'],types:['Gaming Mouse','Mechanical Keyboard','Gaming Headset','Controller','Gaming Monitor','Console Accessory'],models:['Pulse','Viper','BlackShark','ROG','Nitro','Elite','G502','K-Series'],base:[1499,2499,3999,5999,9999,15999,24999,49999],tags:['RGB','Wireless','144Hz','165Hz','240Hz','2.4GHz']},
  Watches:{count:600,brands:['Apple','Samsung','Noise','boAt','Fossil','Titan','Fire-Boltt','Garmin'],types:['Smartwatch','Fitness Watch','Classic Watch','Hybrid Watch','Sports Watch'],models:['Watch','Galaxy Watch','ColorFit','Lunar','Gen','Instinct','Chronograph','Steel'],base:[1499,2499,3999,5999,8999,14999,29999],tags:['AMOLED','GPS','Bluetooth Calling','SpO2','7-day battery']},
  Cameras:{count:500,brands:['Canon','Nikon','Sony','Fujifilm','GoPro','DJI','Panasonic'],types:['Mirrorless Camera','DSLR Camera','Action Camera','Vlogging Camera','Camera Lens'],models:['EOS','Alpha','Z','X-Series','Hero','Osmo','Lumix'],base:[29999,44999,59999,79999,99999,129999,169999],tags:['4K','24MP','APS-C','Full Frame','Wi-Fi']},
  Electronics:{count:1200,brands:['Philips','Belkin','Anker','TP-Link','Portronics','Syska','Havells','Mi','Sony','JBL'],types:['Power Bank','Charger','Cable','Router','Power Strip','USB Hub','Keyboard','Mouse','Webcam','Smart Device'],models:['PowerCore','GaN','Boost','Link','Pro','Smart','Essential','Max'],base:[399,699,999,1499,1999,2999,4999,7999],tags:['USB-C','65W','10000mAh','20000mAh','Wi-Fi 6','Fast Charging']},
  "Men's Fashion":{count:900,brands:['Levi\'s','U.S. Polo Assn.','Roadster','Jack & Jones','Puma','H&M','Allen Solly','Van Heusen'],types:['Regular T-Shirt','Oversized T-Shirt','Casual Shirt','Jeans','Chinos','Hoodie','Jacket','Polo T-Shirt'],models:['Classic','Essential','Urban','Slim','Comfort','Relaxed','Premium','Everyday'],base:[599,799,999,1299,1599,1999,2499,3499],tags:['Cotton','Slim Fit','Regular Fit','Stretch','Solid','Printed']},
  "Women's Fashion":{count:900,brands:['Libas','Biba','H&M','ONLY','Roadster','Vero Moda','Aurelia','SASSAFRAS'],types:['Kurta','Top','Dress','Jeans','Saree','Kurtis Set','Jacket','Trousers'],models:['Classic','Floral','Everyday','Elegant','Urban','Comfort','Premium','Printed'],base:[599,799,999,1299,1699,2299,2999,3999],tags:['Cotton','Rayon','Regular Fit','A-Line','Floral','Solid']},
  Shoes:{count:800,brands:['Nike','Adidas','Puma','Skechers','Reebok','Campus','Red Tape','Woodland'],types:['Running Shoes','Sneakers','Walking Shoes','Training Shoes','Casual Shoes','Loafers','Boots'],models:['Air','Court','Flex','Runner','Lite','Street','Comfort','Pro'],base:[999,1499,1999,2499,2999,3999,5999,8999],tags:['Lightweight','Mesh','Memory Foam','Slip Resistant','Cushioned']},
  Bags:{count:600,brands:['American Tourister','Skybags','Wildcraft','Safari','Puma','F Gear','Mokobara','Lavie'],types:['Laptop Backpack','Casual Backpack','Sling Bag','Tote Bag','Duffel Bag','Travel Trolley','Handbag'],models:['Urban','Classic','Voyage','Pro','Essential','Metro','Weekend','City'],base:[799,1199,1599,2199,2999,3999,5999,8999],tags:['Water Resistant','15.6 inch','Lightweight','Cabin Size','Organiser']},
  Beauty:{count:700,brands:['Lakme','Maybelline','L\'Oreal Paris','Mamaearth','Minimalist','The Derma Co','Nivea','Plum'],types:['Face Serum','Face Wash','Moisturizer','Sunscreen','Shampoo','Lipstick','Foundation','Hair Care Kit'],models:['Glow','Hydra','Daily','Matte','Vitamin C','Hydrating','Pro','Care'],base:[249,399,499,699,999,1299,1699,2499],tags:['Vitamin C','SPF 50','Oil Free','Dermat Tested','Long Lasting']},
  Printers:{count:300,brands:['HP','Canon','Epson','Brother','Pantum'],types:['Ink Tank Printer','All-in-One Printer','Laser Printer','Photo Printer','Mono Printer'],models:['DeskJet','LaserJet','PIXMA','EcoTank','L3150','DCP','Smart Tank','Laser'],base:[4999,6999,8999,11999,15999,19999,24999],tags:['Wi-Fi','Duplex','Colour','All-in-One','Mobile Print']}
};

const pad=(n,w=3)=>String(n).padStart(w,'0');
const hash=(n,m)=>((n*9301+49297)%233280)%m;
const clampPrice=n=>Math.max(199,Math.round(n/10)*10);
const imageQueries = {
  Mobiles:'smartphone phone product', Laptops:'laptop computer product', Audio:'headphones earbuds speaker product',
  TVs:'smart tv television product', Gaming:'gaming console controller keyboard mouse', Watches:'smartwatch wrist watch product',
  Cameras:'camera lens photography product', Electronics:'electronics gadget charger powerbank',
  "Men's Fashion":'mens clothing tshirt shirt jeans fashion', "Women's Fashion":'womens clothing dress kurti fashion',
  Shoes:'shoes sneakers footwear product', Bags:'backpack handbag travel bag product', Beauty:'beauty skincare cosmetics product',
  Printers:'printer office printer product'
};
const productImage=(category,type,id,angle=0)=>{
  const q=encodeURIComponent(`${imageQueries[category]||category} ${type||''}`.trim());
  return `https://loremflickr.com/900/900/${q}?lock=${id*7+angle}`;
};

export const products = [];
let id=1;
for(const [category,cfg] of Object.entries(configs)){
  for(let i=0;i<cfg.count;i++){
    const brand=cfg.brands[hash(i+id, cfg.brands.length)];
    const type=cfg.types[hash(i*3+id,cfg.types.length)];
    const modelPool=brandModels[category]?.[brand] || cfg.models; const model=modelPool[hash(i*5+id,modelPool.length)];
    const tag=cfg.tags[hash(i*7+id,cfg.tags.length)];
    const base=cfg.base[hash(i*11+id,cfg.base.length)];
    const variant=hash(i*13+id,8)+1;
    const price=clampPrice(base*(0.94+((hash(i*17+id,13)-6)/100)));
    const mrp=clampPrice(price*(1.12+hash(i*19+id,18)/100));
    const rating=(4.0+hash(i*23+id,11)/10).toFixed(1);
    const reviews=120+hash(i*29+id,18500);
    const image=productImage(category,type,id);
    const gallery=[productImage(category,type,id,1),productImage(category,type,id,2),productImage(category,type,id,3)];
    const name=`${brand} ${model} ${type} ${tag} ${variant}`;
    products.push({
      id,
      name,
      category,
      brand,
      price,
      mrp,
      discount:Math.max(1,Math.round((1-price/mrp)*100)),
      image,
      gallery,
      rating,
      reviews,
      stock: 4+hash(i*31+id,96),
      keywords:[category.toLowerCase(),brand.toLowerCase(),type.toLowerCase(),tag.toLowerCase()],
      description:`${brand} ${type} designed for everyday Indian shoppers. Includes ${tag.toLowerCase()} features with practical value and a clean Zelvio catalog price.`,
      specs:{Brand:brand,Category:category,Type:type,Feature:tag,Model:`${model}-${pad(variant)}`}
    });
    id++;
  }
}

export const productCount = products.length;
export const categoryMeta = Object.fromEntries(categories.map(c=>[c[0],c]));
export { money };
